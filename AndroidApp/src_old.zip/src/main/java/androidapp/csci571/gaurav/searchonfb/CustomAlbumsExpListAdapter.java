package androidapp.csci571.gaurav.searchonfb;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.List;

import static java.security.AccessController.getContext;

/**
 * Created by Gaurav on 4/18/2017.
 */

public class CustomAlbumsExpListAdapter extends BaseExpandableListAdapter {

    private Context context;
    private List<String> albumTitles;
    private HashMap<String,List<String>> albumImages;

    public CustomAlbumsExpListAdapter(Context context, List<String> albumTitles, HashMap<String, List<String>> albumImages) {
        this.context = context;
        this.albumTitles = albumTitles;
        this.albumImages = albumImages;
    }


    @Override
    public int getGroupCount() {
        return albumTitles.size();

    }

    @Override
    public int getChildrenCount(int groupPosition) {
        //return 0;
       // if(getGroupCount()==0) return 0;
        return albumImages.get(albumTitles.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
      //  if(albumTitles.size()==0) return null;
        return albumTitles.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
      //  if(albumTitles.size()==0) return null;

        return albumImages.get(albumTitles.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {



        if(convertView==null)
        {

            LayoutInflater inflater =(LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.result_album_list_group,null);
        }


        String albumTitle=(String)getGroup(groupPosition);
        TextView tv=(TextView) convertView.findViewById(R.id.album_list_header);
        tv.setText(albumTitle);
        return convertView;


    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

       try{
        String albumImage=(String)getChild(groupPosition,childPosition);
        if(convertView==null)
        {

            LayoutInflater inflater =(LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.result_album_list_item,null);
        }
        ImageView iv1=(ImageView)convertView.findViewById(R.id.album_image_view);
        //new LoadHighResImage(iv1).execute(albumImage);
        Picasso.with(context).load(albumImage).into(iv1);
       /* TextView tv1=(TextView) convertView.findViewById(R.id.res_album_item_text);
        tv1.setText(albumImage);*/
        return  convertView;

    }catch(Exception e){e.printStackTrace();}
    return null;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    public void populateImage(ImageView iv1,Bitmap bm1)

    {
        iv1.setImageBitmap(bm1);

    }
    public class LoadHighResImage extends AsyncTask<String,Void,Bitmap>
    {
        ImageView iv;

        public LoadHighResImage(ImageView iv) {
            this.iv = iv;
        }

        @Override
        protected Bitmap doInBackground(String... params) {


                try {
                   return (BitmapFactory.decodeStream((InputStream)new URL(params[0]).getContent()));


                } catch (IOException e) {
                    e.printStackTrace();}
                return null;
            }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            //super.onPostExecute(bitmap);
            populateImage(iv,bitmap);
        }
    }
}
