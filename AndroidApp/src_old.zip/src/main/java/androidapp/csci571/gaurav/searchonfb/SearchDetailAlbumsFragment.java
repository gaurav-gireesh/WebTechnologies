package androidapp.csci571.gaurav.searchonfb;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Gaurav on 4/18/2017.
 */

public class SearchDetailAlbumsFragment extends Fragment {
    private ExpandableListView explv;
    private CustomAlbumsExpListAdapter albumAdapter;
    private List<String> albumTitles;
    private HashMap<String,List<String>> albums;
    private String incomingDetailJSON;
    JSONObject incomingAlbums;
    public String getIncomingDetailJSON() {
        return incomingDetailJSON;
    }

    public void setIncomingDetailJSON(String incomingDetailJSON) {
        this.incomingDetailJSON = incomingDetailJSON;
    }



    @Nullable
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        int length=0;
        try{ length=new JSONObject(incomingDetailJSON).optJSONObject("albums").optJSONArray("data").length();}catch(Exception e){e.printStackTrace();}
        // System.out.println("The incoming PageString is"+userString+"***");
        if(length!=0){
            // System.out.println("True");



            return inflater.inflate(R.layout.search_detail_albums_tab,container,false);
        }
        else
        { System.out.println("False");
            View view1=inflater.inflate(R.layout.search_detail_albums_tab,container,false);

            RelativeLayout parent=(RelativeLayout) view1.findViewById(R.id.albumRelativeLayout);
            TextView noPageText=new TextView(getContext());
            noPageText.setText("No albums available to  display");
            noPageText.setTypeface(null, Typeface.BOLD);
            noPageText.setTextSize(24.0f);
            noPageText.setTextColor(Color.BLACK);
            RelativeLayout.LayoutParams textParams=new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
            textParams.addRule(RelativeLayout.CENTER_HORIZONTAL  );
            parent.addView(noPageText,textParams);
            return parent;

        }


    }

   /* @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //
try {

    //albumAdapter= new CustomAlbumsExpListAdapter(getContext(),albumTitles,albumAdapter);
    return inflater.inflate(R.layout.search_detail_albums_tab, container, false);
}catch(Exception e){e.printStackTrace();}return null;}*/

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        explv = (ExpandableListView) getActivity().findViewById(R.id.albumListView);

        initializeData();
        System.out.println("In Albums Fragment: the sizes of albums and hash map are "+albumTitles.size()+" and "+albums.size());

        if(incomingAlbums!=null){
        albumAdapter= new CustomAlbumsExpListAdapter(getContext(),albumTitles,albums);
        explv.setAdapter(albumAdapter);}

        else{
            /*Intent intent=new Intent(getActivity(),AboutMeActivity.class);
            startActivity(intent);*/

        }
    }

    public void initializeData()
    {

        albumTitles=new ArrayList<>();
        albums=new HashMap<>();

        try {

            System.out.println("In Albums Fragment while Initializing: length of the incoming string is "+getIncomingDetailJSON().length());
            JSONObject incomingJSONData = new JSONObject(getIncomingDetailJSON());
             incomingAlbums=incomingJSONData.optJSONObject("albums");
            if(incomingAlbums!=null)
            {
            JSONArray albumJSONArray=incomingAlbums.getJSONArray("data");
            System.out.println("Albums data length ="+albumJSONArray.length());
            for(int i=0;i<albumJSONArray.length();i++)
            {
                String albumTitle=albumJSONArray.getJSONObject(i).getString("name");
                albumTitles.add(albumTitle);
                List<String> imageNames=new ArrayList<String>();

                if(albumJSONArray.getJSONObject(i).optJSONObject("photos")!=null){


                JSONArray photosArray=albumJSONArray.getJSONObject(i).optJSONObject("photos").getJSONArray("data");

                for(int j=0;j<photosArray.length();j++)
                {
                    JSONArray images=photosArray.getJSONObject(j).getJSONArray("images");
                    String img1Src=images.getJSONObject(0).getString("source");
                    imageNames.add(img1Src);

                }

                albums.put(albumTitle,imageNames);



            }else
                {albums.put(albumTitle,new ArrayList<String>());}
            }}
            else{

            }


        }
        catch(Exception e)
        {
            System.out.println("in class SearchAlbumsDetailFragment:"); e.printStackTrace();

        }


    }

}
