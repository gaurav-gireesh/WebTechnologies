package androidapp.csci571.gaurav.searchonfb;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class AboutMeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_me);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_about_me);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("About Me");
    }
    @Override
    public Intent getParentActivityIntent() {
        Intent parentIntent= getIntent();
        String className = parentIntent.getStringExtra("ParentClassSource");
        if(className==null){
            className="androidapp.csci571.gaurav.searchonfb.MainActivity";
        }
        Intent newIntent=null;
        try {
            //you need to define the class with package name
            newIntent = new Intent(this, Class.forName(className));

            if(parentIntent.getIntExtra("tab",-1)!=-1)
            {
                newIntent.putExtra("tab",parentIntent.getIntExtra("tab",-1));
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return newIntent;
    }

}
