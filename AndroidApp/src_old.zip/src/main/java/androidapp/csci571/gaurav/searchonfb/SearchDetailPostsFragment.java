package androidapp.csci571.gaurav.searchonfb;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by Gaurav on 4/18/2017.
 */

public class SearchDetailPostsFragment extends Fragment {
    private String incomingJSON;
    private ListView listView;
    private CustomPostsListAdapter postAdapter;
    private JSONObject postJSON;
    private JSONObject[] postsArray;

    public String getIncomingJSON() {
        return incomingJSON;
    }

    public void setIncomingJSON(String incomingJSON) {
        this.incomingJSON = incomingJSON;
    }


    @Nullable
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        int length=0;
        try{ length=new JSONObject(incomingJSON).optJSONObject("posts").optJSONArray("data").length();}catch(Exception e){e.printStackTrace();}
        // System.out.println("The incoming PageString is"+userString+"***");
        if(length!=0){
            // System.out.println("True");



            return inflater.inflate(R.layout.search_detail_posts_tab,container,false);
        }
        else
        { System.out.println("False");
            View view1=inflater.inflate(R.layout.search_detail_posts_tab,container,false);

            RelativeLayout parent=(RelativeLayout) view1.findViewById(R.id.postRelativeLayout);
            TextView noPageText=new TextView(getContext());
            noPageText.setText("No posts available to  display");
            noPageText.setTypeface(null, Typeface.BOLD);
            noPageText.setTextSize(24.0f);
            noPageText.setTextColor(Color.BLACK);
            RelativeLayout.LayoutParams textParams=new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
            textParams.addRule(RelativeLayout.CENTER_HORIZONTAL  );
            parent.addView(noPageText,textParams);
            return parent;

        }


    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        listView = (ListView) getActivity().findViewById(R.id.postsListView);

        initializeData();
        //System.out.println("In Albums Fragment: the sizes of albums and hash map are "+albumTitles.size()+" and "+albums.size());
        if(postJSON!=null){
        postAdapter= new CustomPostsListAdapter(getContext(),postsArray);
        listView.setAdapter(postAdapter);}else{
            }
    }

    public void initializeData()
    {

        try {
            postJSON = new JSONObject(incomingJSON).optJSONObject("posts");

            if(postJSON!=null){
            JSONArray postsJSONArray=postJSON.getJSONArray("data");
                postsArray=new JSONObject[postsJSONArray.length()];
                for(int i=0;i<postsJSONArray.length();i++)
                {
                    postsArray[i]=postsJSONArray.getJSONObject(i);

                }




        }}
        catch(Exception e)
        {

            System.out.println("In Posts Fragment:");
            e.printStackTrace();
        }

    }
}
