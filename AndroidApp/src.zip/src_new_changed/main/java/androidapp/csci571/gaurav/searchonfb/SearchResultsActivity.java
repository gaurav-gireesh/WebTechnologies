package androidapp.csci571.gaurav.searchonfb;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.design.widget.TabLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;


public class SearchResultsActivity extends AppCompatActivity {


    private SectionsPagerAdapter mSectionsPagerAdapter;

    private FBInitialQueryHelper fqh;
    private ViewPager mViewPager;
    SharedPreferences sharedpref;
    private TabLayout tabLayout;




    @Override
    protected void onCreate(Bundle savedInstanceState) {


try {
    super.onCreate(savedInstanceState);

    setContentView(R.layout.activity_search_results);


    Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarSearchResult);
    setSupportActionBar(toolbar);
    getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    System.out.println("SEARCH RESULT ACTIVITY CREATED!!!");

    sharedpref = getSharedPreferences("fbQueryResults", Context.MODE_PRIVATE);


    TabLayout tabLayout = (TabLayout) findViewById(R.id.tabsSearchResult);

    mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
    mViewPager = (ViewPager) findViewById(R.id.containerSearchResult);
    mViewPager.setAdapter(mSectionsPagerAdapter);
    tabLayout.setupWithViewPager(mViewPager);
    tabLayout.setBackgroundColor(Color.WHITE);
    tabLayout.setTabTextColors(Color.BLACK, Color.BLACK);
    tabLayout.getTabAt(0).setIcon(R.drawable.users);
    tabLayout.getTabAt(1).setIcon(R.drawable.pages);
    tabLayout.getTabAt(2).setIcon(R.drawable.events);
    tabLayout.getTabAt(3).setIcon(R.drawable.places);
    tabLayout.getTabAt(4).setIcon(R.drawable.groups);
    if(getIntent().getIntExtra("tab",-1)!=-1){
       mViewPager.setCurrentItem(getIntent().getIntExtra("tab",-1));
    }


}catch(Exception e){e.printStackTrace();}
    }





    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            switch (position)
            {case 0:
                //mSectionsPagerAdapter.notifyDataSetChanged();
                while(sharedpref.getString("user",null)==null);
                UserFragment user=new UserFragment();user.setUserString(sharedpref.getString("user",null));
                return user;
                case 1: while(sharedpref.getString("page",null)==null);PageFragment page=new PageFragment(); page.setPageString(sharedpref.getString("page",null));return page;
                case 2:  while(sharedpref.getString("event",null)==null);EventFragment event=new EventFragment();event.setEventString(sharedpref.getString("event",null)); return event;
                case 3:  while(sharedpref.getString("place",null)==null);PlaceFragment place=new PlaceFragment(); place.setPlaceString(sharedpref.getString("place",null));return place;
                case 4:  while(sharedpref.getString("group",null)==null);GroupFragment group=new GroupFragment();group.setGroupString(sharedpref.getString("group",null));return group;



            }
            return null;

        }

        @Override
        public int getCount() {
            // Show 3 total page_tab.
            return 5;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Users";
                case 1:
                    return "Pages";
                case 2:
                    return "Events ";
                case 3: return "Places";
                case 4: return "Groups";
            }
            return null;
        }
    }
}
