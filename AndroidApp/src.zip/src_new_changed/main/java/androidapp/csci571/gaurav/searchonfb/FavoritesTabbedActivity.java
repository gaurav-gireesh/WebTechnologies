package androidapp.csci571.gaurav.searchonfb;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class FavoritesTabbedActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private SectionsPagerAdapter mSectionsPagerAdapter;
    private ViewPager mViewPager;
    private SharedPreferences sharedPreferences;

    private ArrayList<String> userArrayList;
    private ArrayList<String> pageArrayList;
    private ArrayList<String> placeArrayList;
    private ArrayList<String> eventArrayList;
    private ArrayList<String> groupArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("FAVORITES ACTIVITY CREATED");
        super.onCreate(savedInstanceState);
        sharedPreferences=getSharedPreferences("favorites", Context.MODE_PRIVATE);

        initializeFavorites();
        setContentView(R.layout.activity_favorites_tabbed);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarFavResult);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Favorites");


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_fav);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view_fav);
        navigationView.setNavigationItemSelectedListener(this);
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabsFavResults);
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        mViewPager = (ViewPager) findViewById(R.id.containerFavResult);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        tabLayout.setupWithViewPager(mViewPager);
        tabLayout.setBackgroundColor(Color.WHITE);
        tabLayout.setTabTextColors(Color.BLACK, Color.BLACK);
        tabLayout.getTabAt(0).setIcon(R.drawable.users);
        tabLayout.getTabAt(1).setIcon(R.drawable.pages);
        tabLayout.getTabAt(2).setIcon(R.drawable.events);
        tabLayout.getTabAt(3).setIcon(R.drawable.places);
        tabLayout.getTabAt(4).setIcon(R.drawable.groups);
        if(getIntent().getIntExtra("tab",-1)!=-1){
            mViewPager.setCurrentItem(getIntent().getIntExtra("tab",-1));
        }



    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_fav);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.

            int id = item.getItemId();



            if(id==R.id.about_me)
            {

                Intent intent=new Intent(this,AboutMeActivity.class);
                intent.putExtra("ParentClassSource","androidapp.csci571.gaurav.searchonfb.FavoritesTabbedActivity");
                intent.putExtra("tab",mViewPager.getCurrentItem());
                startActivity(intent);
                return true;
            }
            if(id==R.id.fb_favorites){}
            if(id==R.id.fb_home){startActivity(new Intent(this,MainActivity.class));}

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_fav);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }




    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            switch (position)
            {case 0:

                FavUserFragment user=new FavUserFragment();user.setFavUser(userArrayList);
                return user;
                case 1: FavPageFragment page=new FavPageFragment(); page.setFavPage(pageArrayList);return page;
                case 2: FavEventFragment event=new FavEventFragment();event.setFavEvent(eventArrayList); return event;
                case 3: FavPlaceFragment place=new FavPlaceFragment();place.setFavPlace(placeArrayList); return place;
                case 4: FavGroupFragment group=new FavGroupFragment();group.setFavGroup(groupArrayList);return group;



            }
            return null;

        }

        @Override
        public int getCount() {
            // Show 3 total page_tab.
            return 5;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Users";
                case 1:
                    return "Pages";
                case 2:
                    return "Events ";
                case 3: return "Places";
                case 4: return "Groups";
            }
            return null;
        }
    }

    //This method initializes the Favorites
    public void initializeFavorites()
    {

        userArrayList=new ArrayList<String>();
        pageArrayList=new ArrayList<String>();
        placeArrayList=new ArrayList<String>();
        eventArrayList=new ArrayList<String>();
        groupArrayList=new ArrayList<String>();

        Map<String,String> favs=(Map<String,String>)sharedPreferences.getAll();

            Iterator it = favs.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry)it.next();



                if(pair.getValue().toString().contains("user"))
                {
                    userArrayList.add(pair.getKey().toString()+","+pair.getValue().toString());
                }
                else  if(pair.getValue().toString().contains("page"))
                {
                    pageArrayList.add(pair.getKey().toString()+","+pair.getValue().toString());
                }
                else  if(pair.getValue().toString().contains("place"))
                {
                    placeArrayList.add(pair.getKey().toString()+","+pair.getValue().toString());
                }
                else  if(pair.getValue().toString().contains("event"))
                {
                    eventArrayList.add(pair.getKey().toString()+","+pair.getValue().toString());
                }
                else  if(pair.getValue().toString().contains("group"))
                {
                    groupArrayList.add(pair.getKey().toString()+","+pair.getValue().toString());
                }

                it.remove(); // avoids a ConcurrentModificationException



        }



    }
}
