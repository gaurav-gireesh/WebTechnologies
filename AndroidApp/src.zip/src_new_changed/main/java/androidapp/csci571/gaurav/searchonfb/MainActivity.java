package androidapp.csci571.gaurav.searchonfb;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;

import android.support.v7.widget.Toolbar;

import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.widget.Toast;

import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;

import java.net.URL;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static EditText searchEditText;
    private static Button oksearchbutton;
    private static Button clearbutton;
    private Intent intent1;
    public FetchSearchQuery fetchSearchQuery;
    public FBInitialQueryHelper fba1;
    public JSONObject finalJSON;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    private LocationListener locationListener;
    private LocationManager locationManager;
    private String currentLatitude;
    private String currentLongitude;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode)
        {
            case 10: if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {configureLocation();}


        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        sharedPreferences = getSharedPreferences("fbQueryResults", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        if (sharedPreferences.getString("user", null) != null)
            editor.remove("user");
        if (sharedPreferences.getString("page", null) != null)
            editor.remove("page");
        if (sharedPreferences.getString("event", null) != null)
            editor.remove("event");
        if (sharedPreferences.getString("group", null) != null)
            editor.remove("group");
        if (sharedPreferences.getString("place", null) != null)
            editor.remove("place");
        editor.apply();


        /*setContentView(R.layout.activity_main_fb);*/
        setContentView(R.layout.activity_main_fb);
        searchEditText = (EditText) findViewById(R.id.searchEditText);
        oksearchbutton = (Button) findViewById(R.id.searchButton);
        clearbutton = (Button) findViewById(R.id.clearButton);
        finalJSON = new JSONObject();
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarfb);
        setSupportActionBar(toolbar);

        intent1 = new Intent(this, SearchResultsActivity.class);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        //location related code


        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                //Called when the device location is updated
                currentLatitude=Double.toString(location.getLatitude());
                currentLongitude=Double.toString(location.getLongitude());
                System.out.println("Latitude is "+currentLatitude+"  and Longitude is "+currentLongitude);


            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

                //Checks if the GPS is turned Off
                //Contains initent to take user to the settings panel to allow access to GPS
                Intent intentLocation=new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intentLocation);
            }
        };

        System.out.println("Current Latitude and Longitude"+currentLongitude);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M)
        {if (checkSelfPermission(  Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.INTERNET},10);
            return;
        }}else{

            configureLocation();

        }
        configureLocation();





    }

    private void configureLocation() {

        System.out.println("Configure Location called!");
        locationManager.requestLocationUpdates("gps", 1000, 0, locationListener);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();



        if(id==R.id.about_me)
        {

            Intent intent=new Intent(this,AboutMeActivity.class);
            startActivity(intent);
            return true;
        }
        if(id==R.id.fb_favorites){ startActivity(new Intent(this,FavoritesTabbedActivity.class));}
        if(id==R.id.fb_home){}


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //
        getMenuInflater().inflate(R.menu.fav_menu,menu);
        return true;
    }

    //method to clear the results and editText
    public void clear(View view)
    {
        searchEditText.setText("");

    }

    public void search(View view)
    {

        if(searchEditText.getText().toString()!=null && searchEditText.getText().toString()!="" && searchEditText.getText().toString().length()!=0){

            new FetchSearchQuery().execute(searchEditText.getText().toString(),"user");
            new FetchSearchQuery().execute(searchEditText.getText().toString(),"page");
            new FetchSearchQuery().execute(searchEditText.getText().toString(),"event");
            new FetchSearchQuery().execute(searchEditText.getText().toString(),"place");
            new FetchSearchQuery().execute(searchEditText.getText().toString(),"group");


            startActivity(intent1);
        }
        else {
            Toast.makeText(MainActivity.this,"Please enter a keyword!",Toast.LENGTH_SHORT).show();
        }


    }


    class FetchSearchQuery extends AsyncTask<String,Void,Void> implements java.io.Serializable
    {





        @Override
        protected Void doInBackground(String... params) {

            String urltype="";
            if(params[1].equalsIgnoreCase("place"))
            {
                urltype="http://gghw6-161921.appspot.com?key="+params[0]+"&type=place&lat="+currentLatitude+"&long="+currentLongitude;
            }
            else{
                urltype="http://gghw6-161921.appspot.com?key="+params[0]+"&type="+params[1];}



            String objtype=null;


            try{
                URL url1=new URL(urltype);  //JSONObject response=null;
                BufferedReader br = new BufferedReader(new InputStreamReader(url1.openStream()));
                String strTemp = "";
                String strResponse=null;
                while (null != (strTemp = br.readLine())) {
                    //System.out.println(strTemp);
                    strResponse=strTemp;
                }
                objtype=(strResponse);
                editor.putString(params[1], objtype);
                editor.apply();

            }

            catch(Exception e)
            {   System.out.println("Your stacktrace is:");

                e.printStackTrace();}



            return null;}}
}
