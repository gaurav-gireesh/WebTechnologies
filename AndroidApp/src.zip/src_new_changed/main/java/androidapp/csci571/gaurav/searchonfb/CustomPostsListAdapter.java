package androidapp.csci571.gaurav.searchonfb;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.Layout;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * Created by Gaurav on 4/19/2017.
 */

public class CustomPostsListAdapter extends ArrayAdapter<JSONObject> {

    SharedPreferences sharedPref;
    View customRowView;
    ImageView postImage;
    TextView postName;
    TextView postDate;
    TextView postMessage;
    String picURL;
    String postersName;
    Bitmap Imagedata;

    public CustomPostsListAdapter(Context context, JSONObject[] objects) {
        super(context, R.layout.result_post_list_item, objects);
        sharedPref=context.getSharedPreferences("currentDetailFile",Context.MODE_PRIVATE);
        picURL=sharedPref.getString("picurl",null);
        postersName=sharedPref.getString("name",null);

        SharedPreferences bmpString=context.getSharedPreferences("IMAGE_DATA",Context.MODE_PRIVATE);
        String previouslyEncodedImage = bmpString.getString("image_data", "");
        if( !previouslyEncodedImage.equalsIgnoreCase("") ){
            byte[] b = Base64.decode(previouslyEncodedImage, Base64.DEFAULT);
             Imagedata = BitmapFactory.decodeByteArray(b, 0, b.length);

        }




    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //
        LayoutInflater inflater=LayoutInflater.from(getContext());
        customRowView=inflater.inflate(R.layout.result_post_list_item,parent,false);
        postImage=(ImageView)customRowView.findViewById(R.id.post_image);
        postName=(TextView)customRowView.findViewById(R.id.post_heading);
        postDate=(TextView)customRowView.findViewById(R.id.post_created_time);
        postMessage=(TextView)customRowView.findViewById(R.id.post_message);

        //setting the name of the user or the poster
        postName.setText(postersName);
        postDate.setText(getItem(position).optString("created_time"));
        postMessage.setText(getItem(position).optString("message"));

        Picasso.with(getContext()).load(picURL).into(postImage);
        // postImage.setImageBitmap(Imagedata);
       // new LoadImageTasks().execute(picURL);
        return customRowView;

    }


    public class LoadImageTasks extends AsyncTask<String, Void, Bitmap> {




        @Override
        protected Bitmap doInBackground(String... args) {

            try {
                return BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());

            } catch (IOException e) {
                e.printStackTrace();}
            return null;
        }

        @Override protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                postImage.setImageBitmap(bitmap);
            }
        }
    }
}
