package androidapp.csci571.gaurav.searchonfb;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Gaurav on 4/20/2017.
 */

public class CustomFavListItemAdapter extends ArrayAdapter<String> {


String type;
    int tab=-1;
    View customrowview;TextView tv;ImageView iv; ImageView ivfav;ImageView ivdetail;
    public CustomFavListItemAdapter(@NonNull Context context, ArrayList<String> resource,String types,int tabs) {
        super(context, R.layout.generic_list_item,resource);
        type=types;
        tab=tabs;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater listInflater=LayoutInflater.from(getContext());
        customrowview=listInflater.inflate(R.layout.generic_list_item,parent,false);
        try{
            final int position2=position;
            String singleString=getItem(position);
            String[] itemList=singleString.split(",");
            String itemName=itemList[1];
            String picurl=itemList[3];

            tv=(TextView) customrowview.findViewById(R.id.list_name);
            iv=(ImageView) customrowview.findViewById(R.id.imageView);
            ivfav=(ImageView) customrowview.findViewById(R.id.imageViewFav);
            ivdetail=(ImageView) customrowview.findViewById(R.id.imageViewMore);


            //System.out.println("IN ADAPTER "+singleString.getString("id")+" FAV is "+sharedPref.getString(singleString.getString("id"),null));

                ivfav.setImageResource(R.drawable.favorites_on);

            ivdetail.setImageResource(R.drawable.details);
//System.out.println("Exception text Position:"+position);

            tv.setText(itemName);

            ivdetail.setClickable(true);
            ivdetail.setOnClickListener(
                    new View.OnClickListener(){


                        @Override
                        public void onClick(View v) {
                            try {

                                String singleString2 = getItem(position2);
                                String[] itemList=singleString2.split(",");
                                String itemName1=itemList[1];
                                String picurl1=itemList[3];
                                String itemType = type;
                                String itemid1=itemList[0];

                               // new LoadImageTasks().execute(picurl1);
                                obfuscateCallDetail(itemid1, itemName1, itemType, picurl1);
                                new FetchAlbumsPosts().execute(itemid1);
                            }catch(Exception e)
                            {
                                e.printStackTrace();
                            }


                        }
                    }



            );




            //new LoadImageTask(iv).execute(picurl);
            Picasso.with(getContext()).load(picurl).into(iv);
        }
        catch(Exception e){e.printStackTrace();}
        return customrowview;
    }



    public class LoadImageTask extends AsyncTask<String, Void, Bitmap> {

        ImageView iv2;
        public LoadImageTask(ImageView iv1) {
            iv2=iv1;
        }

        @Override
        protected Bitmap doInBackground(String... args) {

            try {
                return BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());

            } catch (IOException e) {
                e.printStackTrace();}
            return null;
        }

        @Override protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                iv2.setImageBitmap(bitmap);
            }
        }
    }


    public void obfuscateCallDetail(String itemid,String itemName,String itemType,String itemPicUrl )
    {

        try{
            SharedPreferences sharedpref=getContext().getSharedPreferences("currentDetailFile", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedpref.edit();


            if(sharedpref.getString("id",null)!=null) editor.remove("id");
            if(sharedpref.getString("name",null)!=null) editor.remove("name");
            if(sharedpref.getString("type",null)!=null) editor.remove("type");
            if(sharedpref.getString("picurl",null)!=null) editor.remove("picurl");
            editor.apply();

            editor.putString("id",itemid);
            editor.putString("name",itemName);
            editor.putString("type",itemType);
            editor.putString("picurl",itemPicUrl);
            editor.apply();

            //Toast.makeText(getContext(),"in obfuscate id is:"+sharedpref.getString("id",null),Toast.LENGTH_SHORT).show();
            //Intent intent=new Intent(getContext(),ResultDetailTabbedActivity.class);
            // startActivity(intent);
        }

        catch(Exception e)
        {
            System.out.println("In OBFUSCATION::");
            e.printStackTrace();

        }
    }

    public void showDetailsTabs(String s)
    {
        Intent intent=new Intent(getContext(),ResultDetailTabbedActivity.class);
        intent.putExtra("DETAILJSON",s);
        intent.putExtra("ParentClassSource","androidapp.csci571.gaurav.searchonfb.FavoritesTabbedActivity");
        intent.putExtra("tab",tab);
        getContext().startActivity(intent);

    }

    public class FetchAlbumsPosts extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... params) {

            String moreDetailsURL = "http://gghw6-161921.appspot.com?id=" + params[0];

            try {
                URL url1 = new URL(moreDetailsURL);
                BufferedReader br = new BufferedReader(new InputStreamReader(url1.openStream()));
                String strTemp = "";
                String strResponse = null;
                while (null != (strTemp = br.readLine())) {
                    //System.out.println(strTemp);
                    strResponse = strTemp;

                }
                return strResponse;


            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            //
            showDetailsTabs(s);
        }
    }


    public class LoadImageTasks extends AsyncTask<String, Void, Bitmap> {




        @Override
        protected Bitmap doInBackground(String... args) {

            try {
                return BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());

            } catch (IOException e) {
                e.printStackTrace();}
            return null;
        }

        @Override protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                // postImage.setImageBitmap(bitmap);

                SharedPreferences sharedImagePref=getContext().getSharedPreferences("IMAGE_DATA", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor1=sharedImagePref.edit();
                if(sharedImagePref.getString("image_data",null)!=null) editor1.remove("image_data");
                // Bitmap realImage = BitmapFactory.decodeStream(stream);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] b = baos.toByteArray();

                String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
                editor1.putString("image_data",encodedImage);
                editor1.apply();




            }
        }
    }


}
