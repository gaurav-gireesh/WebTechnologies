AboutMeActivity.java
	Based on a layout- activity_about_me.xml. This has an image View displaying my photo and a TextView with my USC ID.
	
MainActivity.java	
	Based on activity_main_fb.xml has a Navigation Drawer menu. This also has a TextView , an EditText for entering the search key and two buttons for CLEAR and SEARCH.
	This class also calls an AsyncTask which does make an HTTP call to my php deployed on Google Cloud to fetch the results. The background task stores this result in shared_preferences file fbQueryResults after replacing the old content on every search.
	This activity starts the SearchResultsActivity which is explained Next.
	
SearchResultsActivity
	Based on activity_search_results.xml. This is a Tabbed Activity in which 5 tabs namely for users,pages,events,places and groups are setup with View Pager component.
	This activity reads from the sharedPreferences file in the previous stage and renders the results in these tabs using a list view.
	
UserFragment
	This is a fragment based on user_tab.xml. This has a list view and it uses an ArrayListAdapter to Iterate over the users and render them appropriately with name, image and 2 icons for favorites and detail disclosure.
	
PageFragment, GroupFragnemt,Place and EventFragment have the same explanation as above to render results of different categories respectively.

ResultDetailsTabbedActivity
	This is again a Tabbed Activity to show Albums and Posts of a selected id in the previous result set. It uses this Id and calls an AsyncTask to fetch albums and post.
	This also has logic for sharing the post on the Facebook Account/wall of the user. This also has a menu option for add/remove to favorites.

FavoriteClassHelper
	This is a normal Java class to make or remove favorites.
	
SearchDetailsAlbumsFragment
	This is the Albums tab which renders top 5 albums in an ExpandableListView for the queried id.
	
SearchDetailsPostsFragment
	This is the tab that renders the messages from queried id posts in a ListViewComponent.
	
FavoritesTabbedActivity
	This activity lists down user favorited items for each category in a Tab Layout similar to SearchResultsActivity.
	
Remaining classes are mostly ListAdapters for ArrayList and Expandable lists for rendering albums, posts and facebook query results and the favorited items.
	