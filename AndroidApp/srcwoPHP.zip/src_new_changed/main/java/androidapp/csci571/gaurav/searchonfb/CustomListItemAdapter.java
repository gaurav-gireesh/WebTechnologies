package androidapp.csci571.gaurav.searchonfb;

import android.content.Context;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;

import android.os.SystemClock;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.ImageView;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;

/**
 * Created by Gaurav on 4/16/2017.
 */

 class CustomListItemAdapter extends ArrayAdapter<JSONObject> {

    SharedPreferences sharedPref;
    String type;
    int tab=-1;
    PageFragment pageFragment;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    View customrowview;TextView tv;ImageView iv; ImageView ivfav;ImageView ivdetail;
    public CustomListItemAdapter( Context context,  JSONObject[] objects,String types,int tab1) {
        super(context, R.layout.generic_list_item, objects);
        tab=tab1;
        pageFragment=new PageFragment();
        type=types;
        sharedPref=context.getSharedPreferences("favorites",Context.MODE_PRIVATE);

    }


    @Override
    public View getView(int position,  View convertView, ViewGroup parent) {
        LayoutInflater listInflater=LayoutInflater.from(getContext());
         customrowview=listInflater.inflate(R.layout.generic_list_item,parent,false);
        try{

        JSONObject singleString=getItem(position);
        final int position2=position;


         tv=(TextView) customrowview.findViewById(R.id.list_name);
            iv=(ImageView) customrowview.findViewById(R.id.imageView);
            ivfav=(ImageView) customrowview.findViewById(R.id.imageViewFav);
            ivdetail=(ImageView) customrowview.findViewById(R.id.imageViewMore);
            ivdetail.setClickable(true);
            ivdetail.setOnClickListener(
                    new View.OnClickListener(){


                        @Override
                        public void onClick(View v) {
                            try {
                                JSONObject singleString2 = getItem(position2);
                                String itemid = singleString2.getString("id");
                                String itemPicUrl = singleString2.getJSONObject("picture").getJSONObject("data").getString("url");
                                String itemName = singleString2.getString("name");
                                String itemType = type;

                                //new LoadImageTasks().execute(itemPicUrl);
                                obfuscateCallDetail(itemid, itemName, itemType, itemPicUrl);
                                new FetchAlbumsPosts().execute(itemid);
                            }catch(Exception e)
                            {
                                e.printStackTrace();
                            }


                        }
                    }



            );


            //System.out.println("IN ADAPTER "+singleString.getString("id")+" FAV is "+sharedPref.getString(singleString.getString("id"),null));
            if(sharedPref.getString(singleString.getString("id"),null)!=null)
            {
                ivfav.setImageResource(R.drawable.favorites_on);
            }else
            ivfav.setImageResource(R.drawable.favorites_off);
            ivdetail.setImageResource(R.drawable.details);


//System.out.println("Exception text Position:"+position);
        tv.setText(singleString.getString("name"));

            //new LoadImageTask(tv,iv).execute(singleString.getJSONObject("picture").getJSONObject("data").getString("url"));
            Picasso.with(getContext()).load(singleString.getJSONObject("picture").getJSONObject("data").getString("url")).into(iv);
            }
       catch(Exception e){e.printStackTrace();}
        return customrowview;
    }


    /*public void onImageLoaded(Bitmap bitmap) {


        iv.setImageBitmap(bitmap);
    }*/

public void onError() {
Toast.makeText(getContext(), "Error Loading Image !", Toast.LENGTH_SHORT).show();
}




    public class LoadImageTask extends AsyncTask<String, Void, Bitmap> {

TextView tv2;ImageView iv2;
        public LoadImageTask(TextView tv1,ImageView iv1) {
            tv2=tv1;iv2=iv1;
        }

        @Override
        protected Bitmap doInBackground(String... args) {

            try {
                return BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());

            } catch (IOException e) {
                e.printStackTrace();}
            return null;
        }

        @Override protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                iv2.setImageBitmap(bitmap);
            } else {onError();
            }
        }
    }












    public void obfuscateCallDetail(String itemid,String itemName,String itemType,String itemPicUrl )
    {

        try{
            SharedPreferences sharedpref=getContext().getSharedPreferences("currentDetailFile", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedpref.edit();

            if(sharedpref.getString("id",null)!=null) editor.remove("id");
            if(sharedpref.getString("name",null)!=null) editor.remove("name");
            if(sharedpref.getString("type",null)!=null) editor.remove("type");
            if(sharedpref.getString("picurl",null)!=null) editor.remove("picurl");
            editor.apply();
            // editor.
            editor.putString("id",itemid);
            editor.putString("name",itemName);
            editor.putString("type",itemType);
            editor.putString("picurl",itemPicUrl);
            editor.apply();

            /*Toast.makeText(getContext(),"in obfuscate id is:"+sharedpref.getString("id",null),Toast.LENGTH_SHORT).show();*/
           /* Intent intent=new Intent(getContext(),ResultDetailTabbedActivity.class);
            startActivity(intent);*/}

        catch(Exception e)
        {
            System.out.println("In OBFUSCATION::");
            e.printStackTrace();

        }
    }




    //START TRY


    public void showDetailsTabs(String s)
    {
        Intent intent=new Intent(getContext(),ResultDetailTabbedActivity.class);
        intent.putExtra("DETAILJSON",s);
        intent.putExtra("tab",tab);
        getContext().startActivity(intent);

    }

    public class FetchAlbumsPosts extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... params) {

            String moreDetailsURL = "http://gghw6-161921.appspot.com?id=" + params[0];

            try {
                URL url1 = new URL(moreDetailsURL);
                BufferedReader br = new BufferedReader(new InputStreamReader(url1.openStream()));
                String strTemp = "";
                String strResponse = null;
                while (null != (strTemp = br.readLine())) {
                    //System.out.println(strTemp);
                    strResponse = strTemp;

                }
                return strResponse;


            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            //
            showDetailsTabs(s);
        }
    }




    //LOADING THE IMAGE IN BACKGROUND
    public class LoadImageTasks extends AsyncTask<String, Void, Bitmap> {




        @Override
        protected Bitmap doInBackground(String... args) {

            try {
                return BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());

            } catch (IOException e) {
                e.printStackTrace();}
            return null;
        }

        @Override protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                // postImage.setImageBitmap(bitmap);

                SharedPreferences sharedImagePref=getContext().getSharedPreferences("IMAGE_DATA",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor1=sharedImagePref.edit();
                if(sharedImagePref.getString("image_data",null)!=null) editor1.remove("image_data");
                // Bitmap realImage = BitmapFactory.decodeStream(stream);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] b = baos.toByteArray();

                String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
                editor1.putString("image_data",encodedImage);
                editor1.apply();




            }
        }
    }
}
