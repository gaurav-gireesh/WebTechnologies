package androidapp.csci571.gaurav.searchonfb;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.design.widget.TabLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.content.SharedPreferences;

import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.share.ShareApi;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;

public class ResultDetailTabbedActivity extends AppCompatActivity {
    private SharedPreferences sharedpref;
    String detailID;
    String detailName;
    String detailPicUrl;
    String detailType;
    String detailedJSON;
    Menu menu;
    private CallbackManager callBackManager;


    private SectionsPagerAdapter mSectionsPagerAdapter;

    //Facebook.sdk

    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sharedpref = getSharedPreferences("currentDetailFile", Context.MODE_PRIVATE);
        detailID = sharedpref.getString("id", null);
        detailName = sharedpref.getString("name", null);
        detailPicUrl = sharedpref.getString("picurl", null);
        detailType=sharedpref.getString("type",null);
        detailedJSON= getIntent().getStringExtra("DETAILJSON");

        System.out.println("The ResultDetailActivity is recreated with detailed JSON as: "+detailedJSON);
       // new FetchAlbumsPosts().execute(detailID);


        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_result_detail_tabbed);

        //FACEBOOK RELATED INITIALIZATION
            FacebookSdk.sdkInitialize(getApplicationContext());
        callBackManager=CallbackManager.Factory.create();
        List<String> permissions= Arrays.asList("publish_actions");
        //loginmanager=LoginManager.getInstance();
       //

       /* loginmanager.registerCallback(callBackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        shareThePost();System.out.println(loginResult.getAccessToken());
                    }

                    @Override
                    public void onCancel() {
                        System.out.println("Heyy oncancel called!!!");
                    }

                    @Override
                    public void onError(FacebookException error) {
                        System.out.println("FACEBOOK ERROR!!!");error.printStackTrace();
                    }
                }


        );//loginmanager.logInWithPublishPermissions(this,permissions);
*/



        //FACEBOOK RELATED STUFF ENDS




        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarResultTabbed);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar();
        getSupportActionBar().setTitle("More Details");

        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        mViewPager = (ViewPager) findViewById(R.id.containerResultTabbed);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabsResultTabbed);
        tabLayout.setupWithViewPager(mViewPager);
        tabLayout.setBackgroundColor(Color.WHITE);
        tabLayout.setTabTextColors(Color.BLACK, Color.BLACK);
        tabLayout.getTabAt(0).setIcon(R.drawable.albums);
        tabLayout.getTabAt(1).setIcon(R.drawable.posts);

       // setContentView(R.layout.activity_result_detail_tabbed);




    }
//For Sharing the POsts

    private void shareThePost() {
        System.out.println("Is this called?");
        ShareDialog shareDialog=new ShareDialog(this);
        shareDialog.registerCallback(callBackManager,
                new FacebookCallback<Sharer.Result>() {


                    @Override
                    public void onSuccess(Sharer.Result result) {
                        Toast.makeText(getBaseContext(),"You shared this post.",Toast.LENGTH_SHORT).show();
                    }@Override
                    public void onCancel() {
                        System.out.println("Heyy oncancel called!!!");  Toast.makeText(getBaseContext(),"Not Shared!",Toast.LENGTH_SHORT).show();
                    }



                    @Override
                    public void onError(FacebookException error) {
                       Toast.makeText(getBaseContext(),"Error in Sharing",Toast.LENGTH_SHORT).show();
                    }
                }


        );
        ShareLinkContent content = new ShareLinkContent.Builder()
                .setContentUrl(Uri.parse("http://facebook.com")).setContentDescription("FB Search from CSCI571 Spring 2017")
                .setImageUrl(Uri.parse(detailPicUrl)).setContentTitle(detailName)
                .build();

        shareDialog.show(content);
        System.out.println(content.getContentUrl());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callBackManager.onActivityResult(requestCode,resultCode,data        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.


        SharedPreferences sharedpreffav=this.getSharedPreferences("favorites",Context.MODE_PRIVATE);
        if(sharedpreffav.getString(detailID,null)!=null)
        getMenuInflater().inflate(R.menu.nonfav_menu, menu);
        else
            getMenuInflater().inflate(R.menu.fav_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.addFavItem) { FavoriteClassHelper favHelper=new FavoriteClassHelper(this,detailID);
            boolean res=favHelper.makeFav(detailName+","+detailType+","+detailPicUrl);
            if(res==true) Toast.makeText(this," Added to Favorites",Toast.LENGTH_SHORT).show();
           /*finish();
            startActivity(getIntent());*/ //getMenuInflater().inflate(R.menu.nonfav_menu, menu);
            return true;
        }
        if(id==R.id.removeFavItem){
            FavoriteClassHelper favHelper=new FavoriteClassHelper(this,detailID);
            boolean res=favHelper.removeFav();
            if(res==true)Toast.makeText(this," Removed from Favorites!",Toast.LENGTH_SHORT).show();
            //finish();startActivity(getIntent());
           // getMenuInflater().inflate(R.menu.fav_menu, menu);
            return  true;

        }
        if(id==R.id.ShareItem)
        {
            Toast.makeText(getBaseContext(),"Sharing " +detailName+"!!",Toast.LENGTH_LONG).show();
            shareThePost();return true;
        }
        {

        }

        return super.onOptionsItemSelected(item);
    }



    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).

            switch (position) {
                case 0:
                    try {

                          //  System.out.println("In TabbedActivity the json passed is:"+detailedJSON+ "\nthe length is :"+detailedJSON.length());
                        SearchDetailAlbumsFragment albums = new SearchDetailAlbumsFragment();albums.setIncomingDetailJSON(detailedJSON);
                        return albums;
                    } catch (Exception e) {
                        System.out.println("ResultDetailTabbedActivity");
                        e.printStackTrace();
                    }


                case 1:
                    SearchDetailPostsFragment posts = new SearchDetailPostsFragment();posts.setIncomingJSON(detailedJSON);
                    return posts;

            }
            return null;
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Albums";
                case 1:
                    return "Posts";

            }
            return null;
        }
    }

//Handling parent Activity


    @Override
    public Intent getParentActivityIntent() {
        Intent parentIntent= getIntent();
        String className = parentIntent.getStringExtra("ParentClassSource");
        if(className==null){
            className="androidapp.csci571.gaurav.searchonfb.SearchResultsActivity";
        }

        Intent newIntent=null;
        try {
            //you need to define the class with package name
            newIntent = new Intent(this, Class.forName(className));
            newIntent.putExtra("tab",this.getIntent().getIntExtra("tab",0));

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return newIntent;
    }




}