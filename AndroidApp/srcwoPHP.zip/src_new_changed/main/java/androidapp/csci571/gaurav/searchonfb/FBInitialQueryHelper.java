package androidapp.csci571.gaurav.searchonfb;

import org.json.JSONObject;

/**
 * Created by Gaurav on 4/16/2017.
 */

public class FBInitialQueryHelper implements java.io.Serializable {
    public String user;
    public String page;


    public String event;
    public String place;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String group;
}
