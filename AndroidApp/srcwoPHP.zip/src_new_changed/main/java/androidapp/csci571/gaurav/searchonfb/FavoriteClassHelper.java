package androidapp.csci571.gaurav.searchonfb;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Gaurav on 4/19/2017.
 */

public class FavoriteClassHelper {
    SharedPreferences sharedPref;
    String favId;
    SharedPreferences.Editor editor;
    Activity activity;

    public FavoriteClassHelper( Activity act,String favId) {
        activity=act;
        this.sharedPref = activity.getSharedPreferences("favorites", Context.MODE_PRIVATE);
        editor=sharedPref.edit();
        this.favId = favId;
    }

    public boolean makeFav(String favValue)
    {
        if(sharedPref.getString(favId,null)!=null){return true;}
        else{

            System.out.println("In Make favorite with the url as: " +favValue);
        editor.putString(favId,favValue);
        editor.apply();
        return true;}


    }

    public boolean removeFav()
    {
        if(sharedPref.getString(favId,null)!=null){
            editor.remove(favId);editor.apply();return true;
        }
        return false;
    }
}
