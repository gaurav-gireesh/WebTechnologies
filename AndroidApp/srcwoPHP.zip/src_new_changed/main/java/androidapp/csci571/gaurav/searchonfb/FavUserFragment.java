package androidapp.csci571.gaurav.searchonfb;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Gaurav on 4/20/2017.
 */

public class FavUserFragment extends Fragment {

    private ArrayList<String> favUser;

    public ArrayList<String> getFavUser() {
        return favUser;
    }

    public void setFavUser(ArrayList<String> favUser) {
        this.favUser = favUser;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {


        return inflater.inflate(R.layout.fav_user_tab,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        //super.onViewCreated(view, savedInstanceState);
if(favUser.size()!=0){
        ListAdapter genericListAdapter=new CustomFavListItemAdapter(getContext(),favUser,"user",0);
        ListView genericlistview=(ListView) getActivity().findViewById(R.id.generic_list_view_fav_user);

        genericlistview.setAdapter(genericListAdapter);

     /*   genericlistview.setOnItemClickListener(
                new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        try {
                            String item=parent.getItemAtPosition(position).toString();
                            String itemsSplitted[]=item.split(",");

                            String itemid = itemsSplitted[0];
                            String itemName = itemsSplitted[1];
                            String itemType = "user";
                            String itemPicUrl = itemsSplitted[3];

                            new LoadImageTasks().execute(itemPicUrl);

                            obfuscateCallDetail(itemid,itemName,itemType,itemPicUrl);
                            new FetchAlbumsPosts().execute(itemid);
                        }
                        catch(Exception e)
                        {
                            e.printStackTrace();
                        }

                        //try{Toast.makeText(getContext(),singleString.getString("id"),Toast.LENGTH_SHORT).show();} catch(Exception e){e.printStackTrace();}
                    }
                }

        );

*/


    }}


    public void obfuscateCallDetail(String itemid,String itemName,String itemType,String itemPicUrl )
    {

        try{
            SharedPreferences sharedpref=getActivity().getSharedPreferences("currentDetailFile", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedpref.edit();


            if(sharedpref.getString("id",null)!=null) editor.remove("id");
            if(sharedpref.getString("name",null)!=null) editor.remove("name");
            if(sharedpref.getString("type",null)!=null) editor.remove("type");
            if(sharedpref.getString("picurl",null)!=null) editor.remove("picurl");
            editor.apply();

            editor.putString("id",itemid);
            editor.putString("name",itemName);
            editor.putString("type",itemType);
            editor.putString("picurl",itemPicUrl);
            editor.apply();

            //Toast.makeText(getContext(),"in obfuscate id is:"+sharedpref.getString("id",null),Toast.LENGTH_SHORT).show();
            //Intent intent=new Intent(getContext(),ResultDetailTabbedActivity.class);
            // startActivity(intent);
        }

        catch(Exception e)
        {
            System.out.println("In OBFUSCATION::");
            e.printStackTrace();

        }
    }
    public void showDetailsTabs(String s)
    {
        Intent intent=new Intent(getContext(),ResultDetailTabbedActivity.class);
        intent.putExtra("DETAILJSON",s);
        intent.putExtra("ParentClassSource","androidapp.csci571.gaurav.searchonfb.FavoritesTabbedActivity");
        intent.putExtra("tab",0);
        startActivity(intent);

    }

    public class FetchAlbumsPosts extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... params) {

            String moreDetailsURL = "http://gghw6-161921.appspot.com?id=" + params[0];

            try {
                URL url1 = new URL(moreDetailsURL);
                BufferedReader br = new BufferedReader(new InputStreamReader(url1.openStream()));
                String strTemp = "";
                String strResponse = null;
                while (null != (strTemp = br.readLine())) {
                    //System.out.println(strTemp);
                    strResponse = strTemp;

                }
                return strResponse;


            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            //
            showDetailsTabs(s);
        }
    }


    public class LoadImageTasks extends AsyncTask<String, Void, Bitmap> {




        @Override
        protected Bitmap doInBackground(String... args) {

            try {
                return BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());

            } catch (IOException e) {
                e.printStackTrace();}
            return null;
        }

        @Override protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                // postImage.setImageBitmap(bitmap);

                SharedPreferences sharedImagePref=getActivity().getSharedPreferences("IMAGE_DATA", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor1=sharedImagePref.edit();
                if(sharedImagePref.getString("image_data",null)!=null) editor1.remove("image_data");
                // Bitmap realImage = BitmapFactory.decodeStream(stream);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] b = baos.toByteArray();

                String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
                editor1.putString("image_data",encodedImage);
                editor1.apply();




            }
        }
    }

}
